#!/bin/bash


esLaborable() {
	fecha=$1
	dia_semana=$(date -d "$fecha" +"%u")
	dia_mes=$(date -d "$fecha" +"%d/%m")
	mes=$(date -d "$fecha" +"%-m")
	semana_del_mes=$((($(date -d "$fecha" +"%-d")-1)/7+1))
	#%-d obtiene el dia del mes sin ceros. el -1 ajusta la base a 0 para incluir la primera semana. el /7 es para sacar la cantidad de semanas que pasaron y el +1 es para que la primer semana sea un 1 y no un 0.
	
	declare -i valorRetorno=0
	case $dia_mes in
		"17/08" | "12/10" | "20/11" )
		if [ $dia_semana -eq 1 ]; then
			echo "No es laborable."
		fi
	esac

	if test $(grep $dia_mes holiday.txt -ic) -ne 0
	then
		echo "La fecha no es laborable."
		if [ $dia_semana -eq 2 ]; then
			echo "Tanto martes como lunes no son laborables."
		valorRetorno=1
		elif [ $dia_semana -eq 4 ]; then
			echo "Tanto jueves como el viernes no son laborables."
		valorRetorno=1

		fi
	valorRetorno=1
	fi


	if [ $dia_semana -eq 6 ] || [ $dia_semana -eq 7 ]; then
			echo "$fecha no es laborable."
			valorRetorno=1
	fi

	if [ $mes -eq 8 ] && [ $dia_semana -eq 1 ] && [ "$semana_del_mes" = 3 ]; then
		echo "No es laborable."
		valorRetorno=1
	elif [ $mes -eq 10 ] && [ $dia_semana -eq 1 ] && [ $semana_del_mes -eq 2 ]; then
		echo "No es laborable."
		valorRetorno=1
	
	elif [ $mes -eq 11 ] && [ $dia_semana -eq 1 ] && [ $semana_del_mes -eq 4 ]; then
		echo "No es laborable."
		valorRetorno=1
	fi

	

	return ${valorRetorno}



}


