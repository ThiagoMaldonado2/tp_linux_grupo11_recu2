#!/bin/bash

proceso=$1

if [ -z "$1" ]; then
echo "Uso: $0 nombre del proceso"
exit 1
fi


if  pgrep -x "$proceso" > /dev/null; then
	echo "El proceso $proceso está en ejecución."
else
	echo "$proceso no en ejecucion"
	mutt -s "Alerta: $proceso no en ejecucion" -- root
fi

