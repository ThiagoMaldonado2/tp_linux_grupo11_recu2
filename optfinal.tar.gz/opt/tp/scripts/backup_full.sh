#!/bin/bash

ARGS="$*"
dest=$1
orig=$2

day=$(date +%Y%m%d)
name=$(tr -d [:punct:] <<< "$orig")
bkp="_bkp_"
bkp_name="$name$bkp$day.tar.gz"


time=$(date +%H:%M:%S)

log() {
	touch log$time
	mv log$time /opt/tp/logs
	echo "$time realizando backup de "$orig" a "$dest"" > /opt/tp/logs/log$time
}

if [ "$1" = "-h" ]; then
	echo "El script tiene que ser ejecutado "backup_full.sh /destino /origen""
else
	if [ -e $dest ]; then
		if [ -e $orig ]; then
			tar -zcvf $dest/$bkp_name $orig
			log
			mutt -s "logs" -a "/opt/tp/logs/log$time" -- root
		else
			echo "No existe $orig"
		fi
	else
		echo "No existe $dest"
	fi
	#mutt -s "logs" -a log$time.txt -- root
	echo "backup realizado"
fi
