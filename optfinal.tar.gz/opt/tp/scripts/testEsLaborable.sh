#!/bin/bash

if [ $# -gt 0 ]; then

	fecha=$1
	date -d $fecha > /dev/null 2>&1

	if [ $? -eq 0 ]; then
		
		source esLaborable.sh

		esLaborable $fecha debug
	else
		echo "Fecha ingresada en formato invalido, YYYY/MM/DD"
	fi
else
	echo "Error, no ingreso ninguna fecha"
fi
